# Kosmos Toolbox

A toolbox that allows the user to change settings of the loader (requires a modified version of loader). It's aimed for the use with tomGER's SDFiles.

## Current Features
- Reading and modifying of the hbmenu launch button combination 
- Actually modifying the hbmenu config as well so settings stick across reboots
- Reading and modifying wether the album or the hbmenu launches by default
